var ship, shipImage, astroid, astroidImage, astroidGroup, bg, bgImage;
var gamestate = "play";
var score = 0;

function preload(){
  shipImage = loadImage("ship.png")
  astroidImage = loadImage("astroidEdited.jpg")
  bgImage =loadImage("star.jpg")
}

function setup() {
  createCanvas(600,600)
  ship = createSprite(300,300, 50, 50)
  ship.addImage(shipImage)
  ship.scale = 0.1
  bg = createSprite(200,200,10, 10)
  bg.addImage(bgImage)
  bg.scale = 100
  ship.depth = bg.depth + 1
  astroidGroup = new Group()
}
  

function draw() {
  if(keyDown("LEFT_ARROW")){
    ship.position.x -= 5
  }
  if(keyDown("RIGHT_ARROW")){
    ship.position.x += 5
  }
  if (gamestate === "end"){
    astroidGroup.destroyEach()
    ship.visible = false
    bg.visible = false
    fill("white")
    textSize(30)
    text("Score:"+score, 300, ship.y)
  }
  if (gamestate === "play"){
    background("black")
    ship.y = camera.position.y
  camera.position.y -= 3
    score = Math.round(score+(frameCount/60))
    astroidSpawn()
  }
  if (astroidGroup.isTouching(ship)){
    gamestate = "end"  
  }

  drawSprites()
}

function astroidSpawn(){
  if (frameCount%20 === 0){
    astroid = createSprite(0, camera.position.y - 350)
    astroid.addImage(astroidImage)
    astroid.x = random(1, 600)
    astroid.scale = 0.5
    astroid.velocityY = 5
    astroid.lifetime = 100
    astroidGroup.add(astroid)
  }
}